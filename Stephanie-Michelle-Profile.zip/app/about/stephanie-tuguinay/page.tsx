const StephanieTuguinayPage = () => {
  return (
    <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
      <div className="md:col-span-1">
        <img
          src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/Stephanie%20Michelle%20Tuguinay-0qKTUIX5aM5EtWgEsFFsFbmRRravLR.png"
          alt="Stephanie Michelle Tuguinay"
          className="w-full h-auto rounded-lg object-cover"
        />
      </div>

      {/* Content */}
      <div className="md:col-span-2">
        <h1 className="text-4xl font-bold text-gray-900 mb-2">Stephanie Michelle Tuguinay</h1>
        <p className="text-lg text-gray-600 mb-6">Web Developer</p>

        <p className="text-gray-700 text-lg leading-relaxed mb-8">
          Stephanie Michelle Tuguinay is a web developer who uses AI tools to help build simple, functional websites and
          apps. She works with things like HTML, CSS, JavaScript, and some AI integrations to make things easier for
          users.
        </p>
      </div>
    </div>
  )
}

export default StephanieTuguinayPage
